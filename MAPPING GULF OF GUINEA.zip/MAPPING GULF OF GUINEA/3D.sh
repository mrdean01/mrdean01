#!/usr/bin/env bash

# Adding contour lines from the geoid grid :
gmt begin 3D png

#add contour map
gmt grdcontour my_gog.nc -Wthinnest,dimgray -C1000 -Gd3c -A1000+f4+o -p130/30

# Adding coastlines, ticks, directional rose
gmt coast -p -B4 -BNESW -Gdimgray -TdjBR+o0.3c+w3c+l 

# Finally , a 3 D mesh plot was drawn on top of the 2 D map :
# Adding 3 D
gmt grdview my_gog.nc -R-13.9/14/-19.9/6.4/-6916/3980 -JZ4i -p130/30 -C3d.cpt \
-N-6916+glightgray -Qi500 -I+d -Wthin -BnSwEZ+b -B -Bz2000+l"Bathymetry and topography (m)" -Y3i



gmt colorbar --FONT_LABEL=8p,0,black --FONT_ANNOT_PRIMARY=7p,0,black \
    --FONT_TITLE=6p,0,black -Cgulf_of_guinea.cpt -Dx8c/-1c+jLC+w10c/0.35+h -Bxaf -By+lm
gmt end

