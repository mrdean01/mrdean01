#!/usr/bin/env bash

#begin plot
gmt begin gulf_of_Guinea png
#set frame properties
	 gmt set GMT_THEME cookbook
#add coastline
	 gmt coast -R-14.5/14.5/-20/6.5 -JM6i -B -W1/0.25p -Na1/0.5p -Gwhite -SDarkTurquoise 
#add inset map
   gmt inset begin -DjTR+w3.8c+o0.2c/0.25c
#add coastline to inset map
	 gmt coast -R-26/55/-38/40 -Da -Gbrown -B0 -EGG+g --MAP_FRAME_TYPE=plain
     gmt inset end	
#end plot 
gmt end show
