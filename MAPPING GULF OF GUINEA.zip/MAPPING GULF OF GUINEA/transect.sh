#!/usr/bin/env bash
#
gmt begin transect png
	# Extract a subset of earth_relief_01m for the East Pacific Rise
	#gmt grdcut @earth_relief_01m -R118W/107W/49S/42S -Gspac_33.nc
	gmt grdcut gebco_2022_n6.5_s-20.0_w-14.0_e14.5.nc -R-13.9/14/-19.9/6.4 -Gmy_gog.nc
	#gmt makecpt -Crainbow -T-5000/-2000
	gmt makecpt -Cgeo.cpt -T-6916/3980 -H > gulf_of_guinea.cpt
	#gmt grdimage spac_33.nc -I+a15+ne0.75 -JM15c -B --FORMAT_GEO_MAP=dddF
	
       gmt grdimage my_gog.nc -Cgulf_of_guinea.cpt -JM6i -I+a15+ne0.75 -B --FORMAT_GEO_MAP=dddF

	cat <<- EOF > transectC.txt
	0.0  4.0
	-11.0  -10.0	
	EOF
	gmt plot -Rmy_gog.nc -W2p,green transectC.txt
	gmt plot -Sc0.25c -Ggreen transectC.txt
	# Generate cross-profiles 400 km long, spaced 20 km, samped every 2km
	# and stack these using the median, write stacked profile
	gmt grdtrack transectC.txt -Gmy_gog.nc -C400k/2k/20k+v -Sm+sstackC.txt > tableC.txt
	gmt plot -W0.5p tableC.txt
	# Show upper/lower values encountered as an envelope
	gmt convert stackC.txt -o0,5 > envC.txt
	gmt convert stackC.txt -o0,6 -I -T >> envC.txt
	gmt plot -R-200/200/-6900/0 -JX15c/7.5c -Glightgray envC.txt -Yh+3c	
	gmt plot -W3p stackC.txt -Bxafg1000+l"crossection distance (km)" -Byaf+l"Depth (m)" -BWSne
	echo "0 -3460 MEDIAN STACKED PROFILE" | gmt text -Gwhite -F+jTC+f14p -Dj8p
	# cleanup
	#rm -f transectA.txt table.txt env.txt stack.txt my_gog.nc
	
gmt end show
