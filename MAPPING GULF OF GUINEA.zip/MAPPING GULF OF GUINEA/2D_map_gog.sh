#!/usr/bin/env bash
#Purpose: Mapping the bathymetry of the gulf of Giunea using General Bathymetric Chart of the Oceans (GEBCO) (https://www.gebco.net)

gmt begin bathymetry
gdalinfo -stats gebco_2022_n6.5_s-20.0_w-14.0_e14.5.nc # to know the statistics of the data set
# Min=-6916.000 Max=3980.000  Mean=-3459.595, StdDev=1980.111

#clipout area of interest from the above input file
gmt grdcut gebco_2022_n6.5_s-20.0_w-14.0_e14.5.nc -R-13.9/14/-19.9/6.4 -Gmy_gog.nc


# create colour ramp using the module 'makecpt'
gmt makecpt -Cgeo.cpt -T-6916/3980 -H > gulf_of_guinea.cpt

# view the raster image 'my_gog.nc' 
gmt grdimage my_gog.nc -Cgulf_of_guinea.cpt -JM6i -I+a15+ne0.75


gmt coast -Ia/thinner,blue -Na -N1/thicker,black -Dh -B -Tdg-13/3+w0.5i+l,,,N

# create contours at
gmt grdcontour my_gog.nc -W1/80/80/80 -C1000 -A1000+f4


# Create colourbar
gmt colorbar --FONT_LABEL=8p,0,black --FONT_ANNOT_PRIMARY=7p,0,black \
    --FONT_TITLE=6p,0,black -Cgulf_of_guinea.cpt -Dx8c/-1c+jBC+w10c/0.35+h -Bxaf -By+lkm

gmt basemap \
    --FONT_LABEL=10p,0,black \
    --FONT_ANNOT_PRIMARY=10p,0,black \
    --MAP_TITLE_OFFSET=0.1c \
    --MAP_ANNOT_OFFSET=0.1c \
    -UBL/-9p/-67p \
    -Lx14.5c/-2.0c+w1000k+l"Scale (km)"+f

gmt end show
