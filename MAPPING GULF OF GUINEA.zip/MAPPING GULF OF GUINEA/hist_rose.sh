#!/usr/bin/env bash

#
# Purpose:	Make standard and polar histograms
# GMT modules:	histogram, rose, subplot
#
gmt begin histogram
   gmt subplot begin 3x2 -A+JTL+o0.8c -Fs15c/9c -M1c
   
   #plot histogram
  gmt histogram tableA.txt -JX4.8i/2.4i -i4 -Bx+l"Topography (m)" -By+l"Frequency"+u" %"\
 -BWSne+t"Histograms"+givory1 -R-6900/0/0/40 -Glightsteelblue1 -W1p -Z1 -T250 -c0,0 -N0+pred -N1+pblue -N2+pgreen
 
 #plot rose diagram
  gmt rose tableA.txt -i4 -A7r -S1.9in -Gwhite -R0/1/0/360 -Bg -B+givory1 -W1p -c0,1
 
  #plot histogram
  gmt histogram tableB.txt -JX4.8i/2.4i -i4 -Bx+l"Topography(m)" -By+l"Frequency"+u"%"\
 -BWSne+t"Histograms"+givory1 -R-6900/0/0/20 -Glightsteelblue1 -W1p -Z1 -T250 -c1,0 -N0+pred -N1+pblue -N2+pgreen
   
  #plot rose diagram 
  gmt rose tableB.txt -i4 -A7r -S1.9in -Gwhite -R0/1/0/360 -Bg -B+givory1 -W1p -c1,1
   
  #plot histogram
  gmt histogram tableC.txt -JX4.8i/2.4i -i4 -Bx+l"Topography (m)" -By+l"Frequency"+u" %"\
 -BWSne+t"Histograms"+givory1 -R-6900/0/0/40 -Glightsteelblue1 -W1p -Z1 -T250 -c2,0 -N0+pred -N1+pblue -N2+pgreen
  
  #plot rose diagram 
  gmt rose tableC.txt -i4 -A7r -S1.9in -Gwhite -R0/1/0/360 -Bg -B+givory1 -W1p -c2,1
   
  
   
   gmt subplot end
gmt end show
